<?php 
namespace App\Models;
use CodeIgniter\Model;

class FormAdminLoginModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
	 protected $returnType     = 'array';
    protected $allowedFields = ['user_login', 'user_email', 'user_pass'];
}