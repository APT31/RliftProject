<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

 <?php
		enqueue_script(10);
		
		
		enqueue_style(10);
	?>
  
  <link rel="stylesheet" href="<?=base_url('assets/css/bootstrap.css'); ?>">
  <link rel="stylesheet" href="<?=base_url('assets/js/bootstrap.js'); ?>">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	
	  <!-- Vendor CSS Files -->
	  	
 <?php
		enqueue_script(9);
		enqueue_style(9);
	?>
  <link href="<?=base_url('assets/vendor/icofont/icofont.min.css'); ?>" rel="stylesheet">
  <link href="<?=base_url('assets/vendor/boxicons/css/boxicons.min.css'); ?>" rel="stylesheet">
  
    <?php
		enqueue_script(8);
		enqueue_style(8);
	?>
	
  
  
  <link href=" <?=base_url('assets/vendor/remixicon/remixicon.css'); ?>" rel="stylesheet">
  <link href="  <?=base_url('assets/vendor/venobox/venobox.css'); ?>" rel="stylesheet">
  <link href="<?=base_url('assets/vendor/owl.carousel/assets/owl.carousel.min.css'); ?>" rel="stylesheet">
  <link href="<?=base_url('assets/vendor/aos/aos.css'); ?>" rel="stylesheet">

    
  <?php
		enqueue_script(7);
		enqueue_style(7);
	?>		
	
 
  <!-- Template Main CSS File -->
  <link href="<?=base_url('assets/css/style.css'); ?>" rel="stylesheet">
  

		 <?php
		enqueue_script(6);
		enqueue_style(6);
	?>
 
	
		
</head>
<body >
 