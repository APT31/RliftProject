<?php

namespace App\Filters;
 
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
 
class NoneSecurityAuth implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
		
		$url = preg_replace('#^.+://[^/]+#', '', current_url());
		
		
        // if user not logged in
        if( session()->get('logged_in') && $url == '/admin/login'){
            // then redirct to login page
            return redirect()->to('/admin'); 
        }
    }
 
    //--------------------------------------------------------------------
 
    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
		
		
	
		
		
    }
}