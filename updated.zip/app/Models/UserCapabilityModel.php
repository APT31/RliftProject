<?php 
namespace App\Models;
use CodeIgniter\Model;

class UserCapabilityModel extends Model
{
    protected $table = 'user_capabilities';
    protected $primaryKey = 'id';
	 protected $returnType     = 'array';
    protected $allowedFields = ['name', 'capabilities', 'slug_name'];
}