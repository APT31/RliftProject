<?= $this->extend($layout) ?>


<?= $this->section('content') ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper pb-4 ">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>New Administrator</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">New Administrator</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
	<?= form_open(base_url('admin/create/new-admin') , 'class="email" id="create-user"' , array("role" => "administrator" , 'redirect'=>base_url('admin/administrator/list')) ) ?>
      <div class="row">
	   
        <div class="col-md-6">
		
		 <div class="card card-primary card-outline">
		 
		
						  <div class="card-body box-profile">
							<div class="text-center">
							  <img class="profile-user-img img-fluid img-circle"
								   src="<?=base_url('dist/img/TB9EWA8NS-UB8NA0ELV-aa7e851f21c3-512.png')?>"
								   alt="User profile picture">
							</div>

							<h3 class="profile-username text-center"><?=$firstname?> <?=$lastname?></h3>

							
							<div class="custom-file text-center">
							<label for="inputName" class="text-center">Profile Image</label>
							  <div class="file-field text-center">
										  <div class="btn btn-primary btn-sm waves-effect waves-light">
											<span>Choose file</span>
											<input type="file" name="profile-image" accept="image/*">
										  </div>
										  
										</div>
							</div>
							
						  </div>
						  <!-- /.card-body -->
						</div>
						
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Personal Information</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="form-group">
                <label for="inputName">First Name</label>
                <input type="text" id="inputName" class="form-control" name="firstname" required>
              </div>
			 <div class="form-group">
                <label for="inputName">Last Name</label>
                <input type="text" id="inputName" class="form-control" name="lastname" required>
              </div>
			
			  <div class="form-group">
                <label for="inputName">Position</label>
                <input type="text" id="inputName" class="form-control" name="position">
              </div>
			  <div class="form-group">
                <label for="inputName">Education</label>
                <input type="text" id="inputName" class="form-control" name="education">
              </div>
			  <div class="form-group">
                <label for="inputName">Location</label>
                <input type="text" id="inputName" class="form-control" name="location">
              </div>
			  <div class="form-group">
                <label for="inputName">Skills</label>
                <input type="text" id="inputName" class="form-control" name="skills">
              </div>
			
              <div class="form-group">
                <label for="inputDescription">Notes</label>
                <textarea id="inputDescription" class="form-control" rows="4" name="notes"></textarea>
              </div>
			  
			  
			  
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <div class="col-md-6">
          <div class="card card-secondary">
            <div class="card-header">
              <h3 class="card-title">Security</h3>

            
            </div>
            <div class="card-body">
			  <div class="form-group">
                <label for="inputName">Email</label>
                <input type="email" id="inputName" class="form-control" name="email"  required>
              </div>
             <div class="form-group">
                <label for="inputClientCompany">Password</label>
                <input type="password" id="newpassword" class="form-control" name="user_pass" required>
              </div>
             <div class="form-group">
                <label for="inputEstimatedBudget">Confirm Password</label>
                <input type="password" id="confirmnewpassword" class="form-control" name="confirmpassword" required>
              </div>
             
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
	 
      <div class="row">
        <div class="col-12">
          <a href="<?=base_url('admin/administrator/list')?>" class="btn btn-secondary">Cancel</a>
          <input type="submit" value="Submit" class="btn btn-success float-right">
        </div>
      </div>
	   </form>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?= $this->endSection() ?>