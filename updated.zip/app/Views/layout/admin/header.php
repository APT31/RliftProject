<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
   <?php
		enqueue_script(10);
		
		
		enqueue_style(10);
	?>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?=base_url('plugins/fontawesome-free/css/all.min.css'); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
   <?php
		enqueue_script(9);
		
		
		enqueue_style(9);
	?>
  
  <link rel="stylesheet" href="<?=base_url('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css'); ?>">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=base_url('plugins/icheck-bootstrap/icheck-bootstrap.min.css'); ?>">
  
     <?php
		enqueue_script(8);
		
		
		enqueue_style(8);
	?>
  <!-- JQVMap -->
  <link rel="stylesheet" href="<?=base_url('plugins/jqvmap/jqvmap.min.css'); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url('dist/css/adminlte.min.css'); ?>">
  
    <?php
		enqueue_script(7);
		
		
		enqueue_style(7);
	?>
    
  <!-- overlayScrollbars -->
  
  <link rel="stylesheet" href="<?=base_url('plugins/overlayScrollbars/css/OverlayScrollbars.min.css'); ?>">
  <!-- Daterange picker -->
  
    
  <link rel="stylesheet" href="<?=base_url('plugins/daterangepicker/daterangepicker.css'); ?>">
  <!-- summernote -->
  <link rel="stylesheet" href="<?=base_url('plugins/summernote/summernote-bs4.min.css'); ?>">
  
    <?php
		enqueue_script(6);
		
		
		enqueue_style(6);
	?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">