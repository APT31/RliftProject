<?php namespace App\Controllers\Auth;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\IncomingRequest;
use App\Models\FormAdminLoginModel;


class AdminAuthentication extends BaseController
{
	
	private $rules;
	private $errors;

	 public function __construct ()
    {
		
	   helper(['form', 'url']);
       $this->rules = [
							'user_email' => ['label' => 'Email', 'rules' => 'required'],
							'user_pass' => ['label' => 'Password', 'rules' => 'required|min_length[10]']
						] ;

		$this->errors = [
			'user_email' => [
				'required' => 'All accounts must have email provided',
			],
			'user_pass' => [
				'validateUser' => 'Email or Password don\'t match',
				'min_length' => 'Your password is required , try again'
			]
		];
    }
	public function authenticate()
	{
		
	
		$loginmodel = new FormAdminLoginModel();
		
		
		
		$validation =  \Config\Services::validation();
		$session = \Config\Services::session($config);
		$request = service('request');
	
		 if ($request->getMethod() == 'post') {
			
			
				$user_email    = $request->getPost('user_email');
				$user_pass = $request->getPost('user_pass');
				
				$verify_email = $loginmodel->where('user_email', $user_email)->first(); 
				
				$validation->setRules($this->rules  , $this->errors);
				
				$validation->withRequest($this->request)->run();
				
				
				if ((!$validation->hasError('user_email')  || !$validation->hasError('user_pass') ) && !empty($verify_email ) )
				{
					$security_pass = $verify_email['user_pass'];
					
					if(md5($user_pass) == $security_pass){
						echo 'Password is valid!';
						
						 $ses_data = [
							'user_id'       => $verify_email['id'],
							'user_login'     => $verify_email['user_login'],
							'email'    => $verify_email['user_email'],
							'nickname'    => $verify_email['user_nicename'],
							'status'    => $verify_email['user_status'],
							'display_name'    => $verify_email['display_name'],
							'logged_in'     => TRUE
						];
						$session->set($ses_data);
						return redirect()->to(base_url('admin') );
					}
					else
					{
						$errors = $validation->getErrors();
						$errors['validateUser'] = 'Email or Password don\'t match';
						unset($errors['user_pass']);
						$session->set('validation_error', $errors);
						return redirect()->to(base_url('admin/login') );
					
					} 
					
					
					
				}
				else
				{
					$errors = $validation->getErrors();
					$session->set('validation_error', $errors);
					return redirect()->to(base_url('admin/login') );
					
				} 
			
		} 
		
	}
	 public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/admin/login');
    }
	//--------------------------------------------------------------------

}
