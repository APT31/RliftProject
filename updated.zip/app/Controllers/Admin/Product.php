<?php namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Product extends BaseController
{
	 public function __construct ()
    {
       
    }
	public function index()
	{
	
		/* helper('helperBaseLayout');
	    return render_view( 'pages/main');  */
		//echo "fasdf";
		  add_style(base_url('assets/css/admin-custom-style.css'), 10 );
		   add_script(base_url('plugins/datatables/jquery.dataTables.min.js'), 4 );
		  add_script(base_url('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/dataTables.responsive.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/responsive.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/dataTables.buttons.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.html5.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.print.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.colVis.min.js'), 4);
		  
		  add_script(base_url('assets//js/admin-datatable-custom.js'), 4);
		 add_script(base_url('assets//js/admin-custom.js'), 4);
		
		  
		  
		  return render_view( 'admin', 'admin_pages/product/product-items');;
	}
	
	public function add_product_item()
	{
	
		/* helper('helperBaseLayout');
	    return render_view( 'pages/main');  */
		//echo "fasdf";
		  
		  
		  return render_view( 'admin', 'admin_pages/product/product-add-item');;
	}
	public function edit_product_item($item = 0)
	{
		/*echo $item;
		 helper('helperBaseLayout');
	    return render_view( 'pages/main');  */
		//echo "fasdf";
		 
		  
		  return render_view( 'admin', 'admin_pages/product/product-edit-item');;
	}
	
	public function product_categories()
	{
		/*echo $item;
		 helper('helperBaseLayout');
	    return render_view( 'pages/main');  */
		//echo "fasdf";
		   add_script(base_url('plugins/datatables/jquery.dataTables.min.js'), 4 );
		  add_script(base_url('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/dataTables.responsive.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/responsive.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/dataTables.buttons.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.html5.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.print.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.colVis.min.js'), 4);
		   add_script(base_url('assets/js/admin-datatable-custom.js'), 4);
		  return render_view( 'admin', 'admin_pages/product/product-categories');;
	}
	

	public function product_brand()
	{
		/*echo $item;
		 helper('helperBaseLayout');
	    return render_view( 'pages/main');  */
		//echo "fasdf";
		   add_script(base_url('plugins/datatables/jquery.dataTables.min.js'), 4 );
		  add_script(base_url('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/dataTables.responsive.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/responsive.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/dataTables.buttons.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.html5.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.print.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.colVis.min.js'), 4);
		   add_script(base_url('assets/js/admin-datatable-custom.js'), 4);
		  return render_view( 'admin', 'admin_pages/product/product-brand');;
	}
	
	public function product_series()
	{
		/*echo $item;
		 helper('helperBaseLayout');
	    return render_view( 'pages/main');  */
		//echo "fasdf";
		   add_script(base_url('plugins/datatables/jquery.dataTables.min.js'), 4 );
		  add_script(base_url('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/dataTables.responsive.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/responsive.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/dataTables.buttons.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.html5.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.print.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.colVis.min.js'), 4);
		   add_script(base_url('assets/js/admin-datatable-custom.js'), 4);
		  return render_view( 'admin', 'admin_pages/product/product-series');;
	}
	
	public function order_list()
	{
		/*echo $item;
		 helper('helperBaseLayout');
	    return render_view( 'pages/main');  */
		//echo "fasdf";
		    add_script(base_url('plugins/datatables/jquery.dataTables.min.js'), 4 );
		  add_script(base_url('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/dataTables.responsive.min.js'), 4);
		  add_script(base_url('plugins/datatables-responsive/js/responsive.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/dataTables.buttons.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.bootstrap4.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.html5.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.print.min.js'), 4);
		  add_script(base_url('plugins/datatables-buttons/js/buttons.colVis.min.js'), 4);
		   add_script(base_url('assets/js/admin-datatable-custom.js'), 4);
		  return render_view( 'admin', 'admin_pages/product/product-orders');;
	}
	//--------------------------------------------------------------------



	public function api_airtable()
	{
		
		$client = \Config\Services::curlrequest();
		
		$response = $client->request('get', 'https://api.airtable.com/v0/appapDN2XsoMtZFVF/Leads?maxRecords=3', [
				'headers' => [
						'Authorization' => 'Bearer keykFSQ9UC5fXPEYH',
				]
		]);
		
		if($response->getStatusCode() == 200){
			echo "<pre>";
			print_r(json_decode( $response->getBody() , true)); 
		}
		
		
		
	}

}
