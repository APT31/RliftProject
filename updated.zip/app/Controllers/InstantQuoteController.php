<?php namespace App\Controllers;

class InstantQuoteController extends BaseController
{
	public function index()
	{
		$data['stylesheets'] = [
			'assets/instant_quote/css/index.css'
		];
		$data['scripts'] = [
			'assets/instant_quote/js/jquery.steps.min.js',
			'assets/instant_quote/js/index.js'
		];
		
	   return render_view( 'frontend', 'pages/instant_quote', $data);
	}

	//--------------------------------------------------------------------

}
