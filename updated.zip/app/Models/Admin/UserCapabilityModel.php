<?php 
namespace App\Models\Admin;
use CodeIgniter\Model;

class UserCapabilityModel extends Model
{
    protected $table = 'user_capabilities';
    protected $primaryKey = 'id';
	 protected $returnType     = 'array';
    protected $allowedFields = ['name', 'capabilities', 'slug_name'];
	
	
	
	public function capabilities($slugs = []) {
		//$db = \Config\Database::connect();
		$this->select('capabilities ' );
		
		$slug_name = array();
		
		
		foreach($slugs as $key => $value){
			if($value){
				$slug_name = $key;
			}
		}
		
		
		
		
		$this->whereIn('slug_name ', $slug_name);
		$getresult = $this->get()->getResultArray();
		$result = array();
		
		if(!empty($getresult)){
			$capabilities = array();
			
			foreach($getresult as $key => $value){
				//if($value["meta_key"] == "capabilities") $value["meta_value"] = unserialize( $value["meta_value"]);
				
				
				
				$unserialize = @unserialize( $value["capabilities"]);
				if ( $value["capabilities"]  === 'b:0;' || $meta_value !== false)$value = $unserialize ; 
				
					$capabilities[]  = array_filter($value['capabilities'], function($a) { return ($a !== false); });
				
				
			}
			if(!empty($getresult))$result["capabilities"] = $this->array_flatten($capabilities);
			
		}
		
		 
		
		 
		 return  $result;
		
	}
	
	 /**
     * Merge as single array the multi dimentional array
     * e.g: echo $this->ClassUtility->array_flatten($multiarray);
     *
     * @param mixed $multiarray Data to convert/single
     * 
     *
     * @return array Instance of the converted array
     */
    function array_flatten($array) { 
	  if (!is_array($array)) { 
		return FALSE; 
	  } 
	  $result = array(); 
	  foreach ($array as $key => $value) { 
		if (is_array($value)) { 
		  $arrayList=$this->array_flatten($value);
		  foreach ($arrayList as $key => $listItem) {
			$result[$key] = $listItem; 
		  }
		} 
	   else { 
		$result[$key] = $value; 
	   } 
	  }  
	  return $result; 
	} 
}


