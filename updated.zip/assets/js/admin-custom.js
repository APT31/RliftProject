/**
* Template Name: Arsha - v3.0.3
* Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/
*/
!(function($) {
  "use strict";

  // Preloader
  $(window).on('load', function() {
		jQuery(".btn-group a.dropdown-item").click(function(){
			document.location = jQuery(this).attr("href");
		})
		
		jQuery("form#profile-update-password , form#create-user").submit(function(e){
			var newpassword = $("#newpassword").val();
			var confirmPassword = $("#confirmnewpassword").val();
			
			if( newpassword == ""){
				 e.preventDefault();
					toastr["error"]("Password is empty")

					toastr.options = {
					  "closeButton": false,
					  "debug": false,
					  "newestOnTop": false,
					  "progressBar": true,
					  "positionClass": "toast-top-right",
					  "preventDuplicates": true,
					  "onclick": null,
					  "showDuration": "300",
					  "hideDuration": "1000",
					  "timeOut": "5000",
					  "extendedTimeOut": "1000",
					  "showEasing": "swing",
					  "hideEasing": "linear",
					  "showMethod": "fadeIn",
					  "hideMethod": "fadeOut"
					}
			}
			 if (newpassword != confirmPassword ){
					 e.preventDefault();
					toastr["error"]("Password Doesn't match")

					toastr.options = {
					  "closeButton": false,
					  "debug": false,
					  "newestOnTop": false,
					  "progressBar": true,
					  "positionClass": "toast-top-right",
					  "preventDuplicates": true,
					  "onclick": null,
					  "showDuration": "300",
					  "hideDuration": "1000",
					  "timeOut": "5000",
					  "extendedTimeOut": "1000",
					  "showEasing": "swing",
					  "hideEasing": "linear",
					  "showMethod": "fadeIn",
					  "hideMethod": "fadeOut"
					}
				}
				else{
					
			
				}
		})
		
		
  });


})(jQuery);