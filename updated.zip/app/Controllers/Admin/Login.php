<?php namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Login extends BaseController
{
	 public function __construct ()
    {
       
    }
	public function index()
	{
	
		  helper(['form', 'url']);
		
		 add_style(base_url('assets/css/admin-custom-style.css'), 10 );
		 add_style(base_url('plugins/toastr/toastr.min.css'), 10 );
		 add_script(base_url('plugins/toastr/toastr.min.js'), 4 );
		 
		 
		 
		 $session = \Config\Services::session($config);
		  $errorlist = $session->get('validation_error');
		  
		
		 
		 $errmsg = "";
		 
		
		 if(!empty($errorlist)){
				
				 foreach($errorlist as $key => $value){
					 // print_r($value );
					  $errmsg .= "&bull;  ". $value . "<br>";
					 
				 }
				 add_script('<script>toastr.error(" '.$errmsg.'"),toastr.options={closeButton:!0,debug:!1,newestOnTop:!1,progressBar:!0,positionClass:"toast-top-center",preventDuplicates:!0,onclick:null,showDuration:"50000",hideDuration:"50000",timeOut:"5000",extendedTimeOut:"1000",showEasing:"swing",hideEasing:"linear",showMethod:"fadeIn",hideMethod:"fadeOut"};</script>', 1 );
				 
				 $session->remove('validation_error');
				 
		   }
		   
		   
		    // $session->setFlashdata('validation_error', '');
		
		  
		 
		  return render_view( 'admin/login', 'admin_pages/login'  );;
	}

	//--------------------------------------------------------------------

}
