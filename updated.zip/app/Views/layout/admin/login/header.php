<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Log in</title>


  <?php
		enqueue_script(10);
		
		
		enqueue_style(10);
	?>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  
    <?php
		enqueue_script(9);
		
		
		enqueue_style(9);
	?>
 
  <link rel="stylesheet" href=" <?=base_url('plugins/fontawesome-free/css/all.min.css'); ?>">
  <!-- icheck bootstrap -->
  
    <?php
		enqueue_script(8);
		
		
		enqueue_style(8);
	?>
  <link rel="stylesheet" href="<?=base_url('plugins/icheck-bootstrap/icheck-bootstrap.min.css'); ?>">
  <!-- Theme style -->
  
    <?php
		enqueue_script(7);
		
		
		enqueue_style(7);
	?>
  <link rel="stylesheet" href="<?=base_url('dist/css/adminlte.min.css'); ?>">
  
  
  <link rel="stylesheet" href="<?=base_url('assets/css/login-style.css'); ?>">
  
    <?php
		enqueue_script(6);
		
		
		enqueue_style(6);
	?>
</head>
<body class="hold-transition login-page">