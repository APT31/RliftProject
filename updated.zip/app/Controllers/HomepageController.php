<?php namespace App\Controllers;

class HomepageController extends BaseController
{
	public function index()
	{
		
		add_style("//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css",1 );
		add_style("https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css",1 );
		add_script("//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js", 2 );
		add_script(base_url('assets/css/custom-style.css'), 4 );
		add_script(base_url('assets/js/custom-script.js'), 4 );
		
	   
	   return render_view( 'frontend', 'pages/homepage'); 
	}

	//--------------------------------------------------------------------

}
