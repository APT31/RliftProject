<?= $this->extend($layout) ?>


<?= $this->section('content') ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper pb-4 ">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Project Edit</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Project Edit</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-6">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">General</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="form-group">
                <label for="inputName">Device Name</label>
                <input type="text" id="inputName" class="form-control" value="Lorem Ipsum">
              </div>
			  <div class="form-group">
                    <label for="customFile">Image</label> 

                    <div class="custom-file">
                      <input type="file" class="custom-file-input" id="customFile">
                      <label class="custom-file-label" for="customFile">Choose file</label>
                    </div>
                  </div>
              <div class="form-group">
                <label for="inputDescription">Device Description</label>
                <textarea id="inputDescription" class="form-control" rows="4" >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</textarea>
              </div>
			    <div class="form-group">
                <label for="inputStatus">Brand</label>
                <select id="inputStatus" class="form-control custom-select">
                  <option  disabled>Select one</option>
                  <option selected>Samsung</option>
                  <option>IPhone</option>
                  <option>Xiomi</option>
                </select>
              </div>
			  <div class="form-group">
                <label for="inputStatus">Category</label>
                <select id="inputStatus" class="form-control custom-select">
                  <option  disabled>Select one</option>
                  <option selected>Tablet</option>
                  <option>Phone</option>
                  <option>Android</option>
                </select>
              </div>
              <div class="form-group">
                <label for="inputStatus">Status</label>
                <select id="inputStatus" class="form-control custom-select">
                  <option  disabled>Select one</option>
                  <option selected>On Hold</option>
                  <option>Canceled</option>
                  <option>Success</option>
                </select>
              </div>
              <div class="form-group">
                <label for="inputClientCompany">Warranty</label>
                <input type="text" id="inputClientCompany" class="form-control" value="Lorem Ipsum">
              </div>
              <div class="form-group">
                <label for="inputProjectLeader">Position</label>
                <input type="number" id="inputProjectLeader" class="form-control" value="1">
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <div class="col-md-6">
          <div class="card card-secondary">
            <div class="card-header">
              <h3 class="card-title">Budget</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
             <div class="form-group">
                <label for="inputClientCompany">Estimated duration</label>
                <input type="text" id="inputClientCompany" class="form-control" value="1 hour">
              </div>
             <div class="form-group">
                <label for="inputEstimatedBudget">Estimated budget</label>
                <input type="number" id="inputEstimatedBudget" class="form-control" value="98">
              </div>
             
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <a href="#" class="btn btn-secondary">Cancel</a>
          <input type="submit" value="Save Changes" class="btn btn-success float-right">
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?= $this->endSection() ?>