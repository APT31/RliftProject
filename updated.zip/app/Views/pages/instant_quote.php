<?= $this->extend($layout) ?>


<?= $this->section('content') ?>

<!-- ======= Hero Section ======= -->
<section id="repair-service-instant-quote" class="d-flex align-items-center">

    <div class="container mt-4 pt-4">
        <div class="text-center text-white">
            <h1 class="hero-title pt-4">Repair Services</h1>
			<div class="row justify-content-center">
				<div class="col-lg-8 text-center pt-4">
					<p class="hero-desc">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque magnam saepe ab
					ratione reprehenderit reiciendis Lorem ipsum, dolor sit amet consectetur adipisicing elit.</p>
					
				</div>
			</div>
            <div class="d-lg-flex mt-4 justify-content-center">
				<a href="#about" class="general-button scrollto">CHOOSE YOUR DEVICE</a>
			  </div>
			 
				<div class="row justify-content-center mt-4 pt-4">
				<div class="col-lg-8 text-center mt-4 pt-4">
					 <img src="<?= base_url('/assets/img/device_repair/banner/image.png') ?>"
                class="d-block hero-img" alt="">
					
				</div>
			</div>
			  
           
        </div>
    </div>



</section><!-- End Hero -->
<section id="choose-your-device">
    <div class="container py-4">
        <div class="section-header text-center"> 
            <h1 class="section-header-title">Choose Your Device</h1>
            <p class="section-header-desc">Lorem ipsum dolor, sit amet consectetur.</p>
        </div>
           <div class="row justify-content-md-center" data-aos-delay="200">

          
		  <div class="col-md-auto mt-4">
			<div class="card" style="width: 18rem;">
			  <img class="card-img-top service-repair" src="assets/img/repair-service/pc_laptop_repair.png" alt="Card image cap">
			  <div class="card-body">
				<p class="card-text text-center mt-2 mb-2">PC Loptop Repair</p>
			  </div>
			</div>
		 </div>
		 
		   <div class="col-md-auto mt-4">
			<div class="card" style="width: 18rem;">
			  <img class="card-img-top service-repair" src="assets/img/repair-service/iphone_repair.png" alt="Card image cap">
			  <div class="card-body">
				<p class="card-text text-center mt-2 mb-2">iPhone Repair</p>
			  </div>
			</div>
		 </div>
		 
		 <div class="col-md-auto mt-4">
			<div class="card" style="width: 18rem;">
			  <img class="card-img-top service-repair" src="assets/img/repair-service/ipad_repair.png" alt="Card image cap">
			  <div class="card-body">
				<p class="card-text text-center mt-2 mb-2">iPad Repair</p>
			  </div>
			</div>
		 </div>
			
			
            <div class="col-md-auto mt-4">
			<div class="card" style="width: 18rem;">
			  <img class="card-img-top service-repair" src="assets/img/repair-service/mac_repair.png" alt="Card image cap">
			  <div class="card-body">
				<p class="card-text text-center mt-2 mb-2">Mac Repair</p>
			  </div>
			</div>
		 </div>
		 
		   <div class="col-md-auto mt-4">
			<div class="card" style="width: 18rem;">
			  <img class="card-img-top service-repair" src="assets/img/repair-service/pc_desktop_repair.png" alt="Card image cap">
			  <div class="card-body">
				<p class="card-text text-center mt-2 mb-2">PC Desktop Repair</p>
			  </div>
			</div>
		 </div>
		 
		 <div class="col-md-auto mt-4">
			<div class="card" style="width: 18rem;">
			  <img class="card-img-top service-repair" src="assets/img/repair-service/smartphone_repair.png" alt="Card image cap">
			  <div class="card-body">
				<p class="card-text text-center mt-2 mb-2">Smartphone Repair</p>
			  </div>
			</div>
		 </div>		  
		  
        </div>
    </div>
</section><!-- End #main -->
<section id="howItWorksSection">
    <div class="container py-4">
        <div class="row">
            <div class="col-6">
                <div class="section-header">
                    <h3 class="section-header-title">How It Works?</h3>
                    <p class="section-header-desc">Lorem ipsum dolor, sit amet consectetur.</p>
                </div>
                <div class="card border-0 how-it-works-card">
                    <div class="row no-gutters">
                        <div class="col-2 card-img-container">
                            <img class=""
                                src="<?= base_url('/assets/img/icons/stop_by_our_store.svg') ?>">
                        </div>
                        <div class="col-10">
                            <div class="card-body">
                                <h5 class="card-title">Stop By Our Store</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum
                                    modi sequi voluptatibus maiores quaerat dolore.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card border-0 how-it-works-card">
                    <div class="row no-gutters">
                        <div class="col-2 card-img-container">
                            <img class="" src="<?= base_url('/assets/img/icons/drop_off.svg') ?>">
                        </div>
                        <div class="col-10">
                            <div class="card-body">
                                <h5 class="card-title">dropoff your device</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum
                                    modi sequi voluptatibus maiores quaerat dolore.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card border-0 how-it-works-card">
                    <div class="row no-gutters">
                        <div class="col-2 card-img-container">
                            <img class=""
                                src="<?= base_url('/assets/img/icons/pay_and_leave_happy.svg') ?>">
                        </div>
                        <div class="col-10">
                            <div class="card-body">
                                <h5 class="card-title">pay and leave happy</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum
                                    modi sequi voluptatibus maiores quaerat dolore.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="container" id="howItWorksImage">
                    <img src="<?= base_url('assets/img/repair/how_it_works/image.png') ?>" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!---section id="whyChooseUsSection">
    <div class="section-header">
        <h3 class="section-header-title">Why Choose Us?</h3>
        <p class="section-header-desc">Lorem ipsum dolor, sit amet consectetur.</p>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-3">
                <div class="why-choose-us-items py-2">
                    <div class="why-choose-us-header">
                        <img src="<?= base_url('assets/img/icons/warranty.svg') ?>" alt="">
                        <p class="why-choose-us-title">1 Year Warranty</p>
                    </div>
                    <div class="why-choose-us-desc">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, sequi!
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="why-choose-us-items py-2">
                    <div class="why-choose-us-header">
                        <img src="<?= base_url('assets/img/icons/fast_repair.svg') ?>" alt="">
                        <p class="why-choose-us-title">repairs in 45 minutes</p>
                    </div>
                    <div class="why-choose-us-desc">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, sequi!
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="why-choose-us-items py-2">
                    <div class="why-choose-us-header">
                        <img src="<?= base_url('assets/img/icons/low_price.svg') ?>" alt="">
                        <p class="why-choose-us-title">low price guarantee</p>
                    </div>
                    <div class="why-choose-us-desc">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, sequi!
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="why-choose-us-items py-2">
                    <div class="why-choose-us-header">
                        <img src="<?= base_url('assets/img/icons/expert_technicians.svg') ?>" alt="">
                        <p class="why-choose-us-title">expert technicians</p>
                    </div>
                    <div class="why-choose-us-desc">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, sequi!
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="buttonsSection">
    <div class="section-header">
        <h3 class="section-header-title">Lorem ipsum dolor sit.</h3>
        <p class="section-header-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi, maxime..</p>
        <div class="buttons">
            <button class="btn btn-light rounded-pill d-inline">request a quote</button>
            <button class="btn btn-outline-light rounded-pill d-inline">ask a question</button>
        </div>
    </div>
</section-->
<?= $this->endSection() ?>