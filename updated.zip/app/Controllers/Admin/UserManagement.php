<?php namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Admin\UserModel;


class UserManagement extends BaseController
{
	 public function __construct ()
    {
       
    }
	
	/*  List of admin 
		@return function html of view render from helper 
	*/
	public function index()
	{
			$usermodel = new UserModel();
			
			$users = $usermodel->get_all_user("administrator");
			
			
			$curr_id = array_search(get_user_id(), array_column($users, 'id'));
			if($curr_id != null)unset($users[$curr_id]);
			
			$data['alluser'] = $users ;
		
		    return render_view( 'admin', 'admin_pages/user_management/administrator-list' , $data);;
	}
	
	
	/*  Page of create new admin
		@return function html of view render from helper 
	*/
	public function new_admin()
	{		
			  helper(['form', 'url']);
			  
			 add_style(base_url('assets/css/admin-custom-style.css'), 10 );
			 add_script(base_url('assets/js/admin-custom.js'), 4);	
		 add_style(base_url('plugins/toastr/toastr.min.css'), 10 );
		 add_script(base_url('plugins/toastr/toastr.min.js'), 4 );
		 
		 
			  $session = \Config\Services::session($config);
		  $errorlist = $session->get('validation_error');
		  
		
		 
		 $errmsg = "";
		 
		
		 if(!empty($errorlist)){
				
				 foreach($errorlist as $key => $value){
					 // print_r($value );
					  $errmsg .= "&bull;  ". $value . "<br>";
					 
				 }
				 add_script('<script>toastr.error(" '.$errmsg.'"),toastr.options={closeButton:!0,debug:!1,newestOnTop:!1,progressBar:!0,positionClass:"toast-top-center",preventDuplicates:!0,onclick:null,showDuration:"50000",hideDuration:"50000",timeOut:"5000",extendedTimeOut:"1000",showEasing:"swing",hideEasing:"linear",showMethod:"fadeIn",hideMethod:"fadeOut"};</script>', 1 );
				 
				 $session->remove('validation_error');
				 
		   }
			 
			 
		    return render_view( 'admin', 'admin_pages/user_management/administrator-new');;
	}
	
	
	/*  Function of create new admin
		@return to the previous url after saving admin
	*/
	public function create_new_admin()
	{		
		$usermodel = new UserModel();
		$validation =  \Config\Services::validation();
		$session = \Config\Services::session($config);
		$request = service('request');
		$redirect = $request->getVar('redirect');
		
		
		 $rules = [
				'user_pass' => ['label' => 'Password', 'rules' => 'required|min_length[10]'],
				'confirmpassword' => ['label' => 'Confirm Password', 'rules' => 'required|matches[user_pass]'],
				'email'        => ['label' => 'Email', 'rules' => 'required|valid_email']
			] ;

		$errors = [
			'user_pass' => [
				'min_length' => 'Your password is too short , try again'
			]
		];
				
		
	
		 if ($request->getMethod() == 'post') {

			$param = $request->getPost();
			$email = $request->getPost('email');
			
			$validation->setRules($rules  , $errors);
				
				$validation->withRequest($this->request)->run();
				
			
				$verifyemail = $usermodel->where('user_email',$email)->countAllResults();
				
				
				
				if(!$validation->hasError('user_pass') && !$validation->hasError('confirmpassword') && $verifyemail == 0){
					//print_r($security_pass );
					 $usermodel->create_user($param);
					 
					 
					if(empty($redirect ))$redirect = previous_url();
					 return redirect()->to($redirect); 
					
				}else{
					$errors = $validation->getErrors();
					
					if($verifyemail !== 0)$errors['email'] = "Email Already exist!";
					
					$session->set('validation_error', $errors);
					
					 
					
				}
		

			$redirect = previous_url();
			return redirect()->to($redirect); 
			 
			 die();
		}
	}

	
	/*  Page of client list
		@return function html of view render from helper 
	*/
	public function client_list()
	{
		helper(['form', 'url']);
		$usermodel = new UserModel();
		
		$users = $usermodel->get_all_user("client");
			
			
			$curr_id = array_search(get_user_id(), array_column($users, 'id'));
			
		
			
			if($curr_id != null)unset($users[$curr_id]);
		
			
			$data['alluser'] = $users ;
		    return render_view( 'admin', 'admin_pages/user_management/client-list' , $data);;
	}
	
	
	/*  Page of create new client
		@return function html of view render from helper 
	*/
	public function new_client()
	{
		helper(['form', 'url']);
			  
		add_style(base_url('assets/css/admin-custom-style.css'), 10 );
		add_script(base_url('assets/js/admin-custom.js'), 4);	
		add_style(base_url('plugins/toastr/toastr.min.css'), 10 );
		add_script(base_url('plugins/toastr/toastr.min.js'), 4 );
	
	   $session = \Config\Services::session($config);
	   $errorlist = $session->get('validation_error');
	
		$errmsg = "";
   
	if(!empty($errorlist)){
		   
			foreach($errorlist as $key => $value){
				// print_r($value );
				 $errmsg .= "&bull;  ". $value . "<br>";
				
			}
			add_script('<script>toastr.error(" '.$errmsg.'"),toastr.options={closeButton:!0,debug:!1,newestOnTop:!1,progressBar:!0,positionClass:"toast-top-center",preventDuplicates:!0,onclick:null,showDuration:"50000",hideDuration:"50000",timeOut:"5000",extendedTimeOut:"1000",showEasing:"swing",hideEasing:"linear",showMethod:"fadeIn",hideMethod:"fadeOut"};</script>', 1 );
			
			$session->remove('validation_error');
			
	  }
		
	   return render_view( 'admin', 'admin_pages/user_management/client-new');;
	}
	
	/*  Function of create new client
		@return to the previous url after saving client
	*/
	public function create_new_client()
	{		
		$usermodel = new UserModel();
		$validation =  \Config\Services::validation();
		$session = \Config\Services::session($config);
		$request = service('request');
		
		 $rules = [
				'user_pass' => ['label' => 'Password', 'rules' => 'required|min_length[10]'],
				'confirmpassword' => ['label' => 'Confirm Password', 'rules' => 'required|matches[user_pass]'],
				'email'        => ['label' => 'Email', 'rules' => 'required|valid_email']
			] ;

		$errors = [
			'user_pass' => [
				'min_length' => 'Your password is too short , try again'
			]
		];
				
		
	
		 if ($request->getMethod() == 'post') {

			$param = $request->getPost();
			$email = $request->getPost('email');
			
			$validation->setRules($rules  , $errors);
				
				$validation->withRequest($this->request)->run();
				
			
				$verifyemail = $usermodel->where('user_email',$email)->countAllResults();
				
				
				
				if(!$validation->hasError('user_pass') && !$validation->hasError('confirmpassword') && $verifyemail == 0){
					//print_r($security_pass );
					 $usermodel->create_user($param);
					 
					 $redirect = $request->getVar('redirect');
					if(empty($redirect ))$redirect = previous_url();
					 return redirect()->to($redirect); 
					
				}else{
					$errors = $validation->getErrors();
					
					if($verifyemail !== 0)$errors['email'] = "Email Already exist!";
					
					$session->set('validation_error', $errors);
					
					 
					
				}
		

			$redirect = previous_url();
			return redirect()->to($redirect); 
			 
			 die();
		}
	}
	
	
	/*  Page of customer list
		@return function html of view render from helper 
	*/
	public function customer_list()
	{
		helper(['form', 'url']);
		$usermodel = new UserModel();
		
		$users = $usermodel->get_all_user("customer");
			
			
			$curr_id = array_search(get_user_id(), array_column($users, 'id'));
			if($curr_id != null)unset($users[$curr_id]);
			
			$data['alluser'] = $users ;
		
		    return render_view( 'admin', 'admin_pages/user_management/customer-list' , $data);;
	}
	
	
	/*  Page of create new customer
		@return function html of view render from helper 
	*/
	public function new_customer()
	{
		helper(['form', 'url']);
			  
		add_style(base_url('assets/css/admin-custom-style.css'), 10 );
		add_script(base_url('assets/js/admin-custom.js'), 4);	
		add_style(base_url('plugins/toastr/toastr.min.css'), 10 );
		add_script(base_url('plugins/toastr/toastr.min.js'), 4 );
	
	   $session = \Config\Services::session($config);
	   $errorlist = $session->get('validation_error');
	
		$errmsg = "";
   
	if(!empty($errorlist)){
		   
			foreach($errorlist as $key => $value){
				// print_r($value );
				 $errmsg .= "&bull;  ". $value . "<br>";
				
			}
			add_script('<script>toastr.error(" '.$errmsg.'"),toastr.options={closeButton:!0,debug:!1,newestOnTop:!1,progressBar:!0,positionClass:"toast-top-center",preventDuplicates:!0,onclick:null,showDuration:"50000",hideDuration:"50000",timeOut:"5000",extendedTimeOut:"1000",showEasing:"swing",hideEasing:"linear",showMethod:"fadeIn",hideMethod:"fadeOut"};</script>', 1 );
			
			$session->remove('validation_error');
			
	  }
		
	   return render_view( 'admin', 'admin_pages/user_management/customer-new');;
	}
	
	
	/*  Function of create new customer
		@return to the previous url after saving customer
	*/
	public function create_new_customer()
	{		
		$usermodel = new UserModel();
		$validation =  \Config\Services::validation();
		$session = \Config\Services::session($config);
		$request = service('request');
		
		 $rules = [
				'user_pass' => ['label' => 'Password', 'rules' => 'required|min_length[10]'],
				'confirmpassword' => ['label' => 'Confirm Password', 'rules' => 'required|matches[user_pass]'],
				'email'        => ['label' => 'Email', 'rules' => 'required|valid_email']
			] ;

		$errors = [
			'user_pass' => [
				'min_length' => 'Your password is too short , try again'
			]
		];
				
		
	
		 if ($request->getMethod() == 'post') {

			$param = $request->getPost();
			$email = $request->getPost('email');
			
			$validation->setRules($rules  , $errors);
				
				$validation->withRequest($this->request)->run();
				
			
				$verifyemail = $usermodel->where('user_email',$email)->countAllResults();
				
				
				
				if(!$validation->hasError('user_pass') && !$validation->hasError('confirmpassword') && $verifyemail == 0){
					//print_r($security_pass );
					 $usermodel->create_user($param);
					 
					 $redirect = $request->getVar('redirect');
					if(empty($redirect ))$redirect = previous_url();
					 return redirect()->to($redirect); 
					
				}else{
					$errors = $validation->getErrors();
					
					if($verifyemail !== 0)$errors['email'] = "Email Already exist!";
					
					$session->set('validation_error', $errors);
					
					 
					
				}
		

			$redirect = previous_url();
			return redirect()->to($redirect); 
			 
			 die();
		}
	}
}