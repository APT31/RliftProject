<?= $this->extend($layout) ?>


<?= $this->section('content') ?>
<div class="modal fade" id="modal-danger" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              <h4 class="modal-title">Danger Modal</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
              <p>One fine body…</p>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-outline-light">Save changes</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
	  
	  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
		  
            <h1 class="m-0">Products</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Products</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

   <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
	  
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <a class="btn btn-block btn-default" style="width: 10%;" href="<?= base_url('admin/product/item/new') ?>">Add New</a>
              </div>
              <!-- /.card-header -->
			  
			 
              <div class="card-body">
                <table id="product-list" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>#SR</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th style="width: 7%;">Status</th>
					  <th style="   width: 13%;">Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  
				  
				  <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#"  data-toggle="modal" data-target="#modal-danger">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				  <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				  <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				  <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				   <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				   <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				   <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				   <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				   <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				   <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				   <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
				   <tr>
                    <td>44235</td>
                    <td> <img class="card-img-top service-repair" src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Card image cap">
			 
                    </td>
                    <td>Note 10 Plus</td>
                    <td> Android Phone</td>
                    <td  class="text-center text-green">  <i class="nav-icon fas  fa-check"></i></td>
                    <td ><div class="btn-group">
                    <button type="button" class="btn btn-success">Action</button>
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <span class="sr-only">Toggle Dropdown</span>
                      <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
                        <a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
                        <a class="dropdown-item" href="#">Delete</a>
                       
                      </div>
                    </button>
                  </div></td>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
			   
            </div>
            <!-- /.card -->
			
          </div>
          <!-- /.col -->
		
        </div>
        <!-- /.row -->
		
      </div>
	  
      <!-- /.container-fluid -->
    </section>
  </div>
  <!-- /.content-wrapper -->
<?= $this->endSection() ?>