<?php namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\Admin\UserModel;


class Profile extends BaseController
{
	 public function __construct ()
    {
       
    }
	public function index()
	{
	
		    helper(['form', 'url']);
			
			
		 add_script(base_url('assets/js/admin-custom.js'), 4);	
		 add_style(base_url('plugins/toastr/toastr.min.css'), 10 );
		 add_script(base_url('plugins/toastr/toastr.min.js'), 4 );
		 
		 
		 
		 $session = \Config\Services::session($config);
		  $errorlist = $session->get('validation_error');
		  
		
		 
		 $errmsg = "";
		 
		
		 if(!empty($errorlist)){
				
				 foreach($errorlist as $key => $value){
					 // print_r($value );
					  $errmsg .= "&bull;  ". $value . "<br>";
					 
				 }
				 add_script('<script>toastr.error(" '.$errmsg.'"),toastr.options={closeButton:!0,debug:!1,newestOnTop:!1,progressBar:!0,positionClass:"toast-top-center",preventDuplicates:!0,onclick:null,showDuration:"50000",hideDuration:"50000",timeOut:"5000",extendedTimeOut:"1000",showEasing:"swing",hideEasing:"linear",showMethod:"fadeIn",hideMethod:"fadeOut"};</script>', 1 );
				 
				 $session->remove('validation_error');
				 
		   }
		   
			
		   $data['firstname'] = get_user_meta( "firstname" );
		   $data['lastname'] = get_user_meta( "lastname" );
		   $data['position'] = get_user_meta( "position" );
		   $data['education'] = get_user_meta( "education" );
		   $data['location'] = get_user_meta( "location" );
		   $data['email'] = get_user_meta( "user_email" );
		   $data['skills'] = get_user_meta( "skills" );
		   $data['notes'] = get_user_meta( "notes" );
		   
		  
		  return render_view( 'admin', 'admin_pages/profile' , $data );;
	}
	public function update_profile()
	{
		
		  
		 $usermodel = new UserModel();
		 $request = service('request');
		 
		
		 
		  if($request->getMethod() == 'post' && !empty($request->getVar())){
			 
			 $data = $request->getVar();
			 foreach($data as $key => $value ){
				   if($key != "redirect" && $key != "capabilities" && $key != "user_level") $usermodel->update_user_meta(get_user_id(), $key ,$value );
				   
				   if($key == "user_email"  && $key != "capabilities" && $key != "user_level") $usermodel->save(array("id" => get_user_id() , "user_email" => $value) );
			 }
			  print_r($request->getVar());
		 } 
		 
		 $redirect = $request->getVar('redirect');
		if(empty($redirect ))$redirect = previous_url();
		 return redirect()->to($redirect);
		 
		 
		/* $usermodel->where('meta_key',"firstname"); 
		
		$data = [
			'meta_value'       => 'darth'
		]; 
		   $usermodel->update( 1, $data);
		   */
		 // return render_view( 'admin', 'admin_pages/profile' , $data );;
	}
	public function update_password()
	{
		
		
		$usermodel = new UserModel();
		 $request = service('request');
		 $validation =  \Config\Services::validation();
		 $session = \Config\Services::session($config);
		 $rules = [
				'newpassword' => ['label' => 'Password', 'rules' => 'required|min_length[10]']
			] ;

		$errors = [
			'newpassword' => [
				'min_length' => 'Your password is too short , try again'
			]
		];
		
		 
		  if($request->getMethod() == 'post' && !empty($request->getVar())){
				
				$verifypassword = $request->getPost('verifypassword');
				$newpassword = $request->getPost('newpassword');
				
				$usermodel->select('user_pass');
				$security_pass = $usermodel->where('id', get_user_id())->first();  
				
				$validation->setRules($rules  , $errors);
				
				$validation->withRequest($this->request)->run();
				
				
				if(md5($verifypassword) == $security_pass['user_pass'] && !$validation->hasError('newpassword')){
					//print_r($security_pass );
					
					 $usermodel->save(array("id" => get_user_id() , "user_pass" => md5($newpassword)) );
				}else{
					$errors = $validation->getErrors();
					
					$session->set('validation_error', $errors);
					
				}
		}
		
		 $redirect = $request->getVar('redirect');
		if(empty($redirect ))$redirect = previous_url();
		 return redirect()->to($redirect);
	}
	//--------------------------------------------------------------------

}
