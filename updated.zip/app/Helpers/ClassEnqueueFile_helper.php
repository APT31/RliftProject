<?php



	 $scriptfiles = array();
	 $stylefiles = array();

   
    /**
     * Merge as single array the script added link
     * 
     *
     * @param  $url is the link
     * @param  $priority positioning of link html teamplte
     *
     * @this store the link as array
     */
    function add_script($url , $priority = 10 ) {
		
		$GLOBALS['scriptfiles'][$priority][] = $url;
		
	/* 	echo "<pre>";
		 print_r($GLOBALS['scriptfiles']);
		echo "</pre>"; */
	} 
	
	 /**
     * Display all the script base on priority 1 to 5 is header 6 to 10 is footer position
     * e.g: $classenqueuefile->enqueue_script(7);
     *
     * @priority is an priority which number will showned
     * 
     */
	function enqueue_script($priority) { 
	
	
	 $thisscript = $GLOBALS['scriptfiles'];
		
	
	  if(empty($priority))return null;
	  if(!isset($thisscript[$priority]))return null;
	  	/* echo "<pre>";
		 print_r($thisscript );
		echo "</pre>"; */
	  foreach($thisscript[$priority] as $value){
		  
		 // echo $value;
		// echo $isValidURL($value);
		  
		if (strncmp($value, "<script", 7) === 0 || strncmp($value, "< script", 8) === 0) {
				 printf('%1$s',$value);
			} else {
				 printf('<script src="%1$s"></script>',$value);
			} 
				  
		  
		  
	   }
	} 
	
	/**
     * Check if valid url
     * e.g: echo $classenqueuefile->isValidURL($url);
     *
     * @param  $url check validation string url
     * 
     *
     * @return preg_match boolean
     */
	 function isValidURL($url)
    {
           // first do some quick sanity checks:
        if(!$url || !is_string($url)){
            return false;
        }
        // quick check url is roughly a valid http request: ( http://blah/... ) 
        if(filter_var($url, FILTER_VALIDATE_URL)){
			return true;
		}
		else{
			return false;
		}
    }
	
	  /**
     * Merge as single array the style added link
     * 
     *
     * @param  $url is the link
     * @param  $priority positioning of link html teamplte
     *
     * @this store the link as array
     */
    function add_style($url , $priority = 10 ) {
		$GLOBALS['stylefiles'][$priority][] = $url;
	} 
	
	 /**
     * Display all the style base on priority 1 to 5 is header 6 to 10 is footer position
     * e.g: $classenqueuefile->enqueue_script(7);
     *
     * @priority is an priority which number will showned
     * 
     */
	function enqueue_style($priority) { 
	
		 $thisstyle = $GLOBALS['stylefiles'];
		 
		 
	  if(empty($priority))return null;
	  if(!isset($thisstyle[$priority]))return null;
	  
	  foreach($thisstyle[$priority] as $value){
		   printf('<link href="%1$s" rel="stylesheet">',
           $value);
		   
		 
		   
	  }  
	} 
    


