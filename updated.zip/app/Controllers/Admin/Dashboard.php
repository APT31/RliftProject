<?php namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Dashboard extends BaseController
{
	 public function __construct ()
    {
       
    }
	public function index()
	{
	
		/* helper('helperBaseLayout');
	    return render_view( 'pages/main');  */
		//echo "fasdf";
		  return render_view( 'admin', 'admin_pages/dashboard');;
	}

	//--------------------------------------------------------------------

}
