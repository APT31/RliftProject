
  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top pt-0">
	   <div class="container-fluid  bg-dark text-white">
		  <div class="container">
			  <div class="row ">
					 <div class="col-lg-6">
						<p class="font-size-sm  mt-2 mb-2">
							Call us: (987) 654-3210
						</p>
					</div>
					<div class="col-lg-6 ">
						<p class="font-size-sm  mt-2 mb-2 text-right">
							Our Location: Cleveland, OH 44121
						</p>
					</div>
			</div>
		</div>
	 </div>
		

    <div class="container d-flex align-items-center pt-3">

      <h1 class="logo me-auto"><a href="/"  class="font-size-md" style="color: #22223C;" >REPAIR<span style="color: #0058FF;">LIFT</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block mx-auto menu-font-size-sm">
        <ul>
          <li><a href="#about">REPAIR</a></li>
          <li><a href="#services">BUY</a></li>
          <li><a href="#portfolio">SELL</a></li>
		   <li class="drop-down"><a href="">ABOUT</a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="drop-down"><a href="#">Deep Drop Down</a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul>
          </li>
          <li><a href="#team">LOCATION</a></li>
         
          <li><a href="#contact">CONTACT</a></li>

        </ul>
      </nav><!-- .nav-menu -->


      <a href="<?= base_url('instant-quote') ?>" class="get-started-btn scrollto font-weight-thin font-size-sm  pt-2 pb-2">INSTANTS QUOTE</a>

    </div>
  </header><!-- End Header -->