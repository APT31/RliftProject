 <?php
		enqueue_script(5);
		
		
		enqueue_style(5);
	?>
<!-- jQuery -->
<script src="<?=base_url('plugins/jquery/jquery.min.js'); ?>"></script>
 <?php
		enqueue_script(4);
		
		
		enqueue_style(4);
	?>
<!-- Bootstrap 4 -->
<script src="<?=base_url('plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
 <?php
		enqueue_script(3);
		
		
		enqueue_style(3);
	?>
<!-- AdminLTE App -->
<script src="<?=base_url('dist/js/adminlte.min.js'); ?>"></script>
 <?php
		enqueue_script(2);
		
		
		enqueue_style(2);
	?>
	
	 <?php
		enqueue_script(1);
		
		
		enqueue_style(1);
	?>
</body>
</html>
