<?php
// namespace App\Controllers;


function render_view( $layout = "defualt", $view, $params = array())
{

	
	if( file_exists(APPPATH.'Views/layout/'.$layout.'/header.php')){
		$html .= view("layout/".$layout."/header" , $params);
	}
	if( file_exists(APPPATH.'Views/layout/'.$layout.'/navigation.php')){
		$html .= view("layout/".$layout."/navigation" , $params );
	}
	if( file_exists(APPPATH.'Views/layout/'.$layout.'/sidebar.php')){
		$html .= view("layout/".$layout."/sidebar" , $params );
	}
	
	 if( file_exists(APPPATH.'Views/'.$view.".php")){
		 
		$params['layout'] =  "layout/".$layout."/content";
		 
		$html .= view($view , $params );
	} 
	else{
		$html .= "Page View Not Exist!";
	}
		
	
	if( file_exists(APPPATH.'Views/layout/'.$layout.'/footer.php')){
		$html .= view("layout/".$layout."/footer" , $params ); 
	}
	
	
	return $html; 
	
}
