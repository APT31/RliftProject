<?php namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php'))
{
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.

 $routes->add('/', 'HomepageController::index');
   $routes->add('instant-quote', 'InstantQuoteController::index');
  
 // $routes->add('admin', 'Admin\Dashboard::index' );
 
$routes->group('admin', function($routes)
{
    $routes->add('/', 'Admin\Dashboard::index' ,['filter' => 'auth']);
    $routes->add('dashboard', 'Admin\Dashboard::index' ,['filter' => 'auth']);
    $routes->add('login', 'Admin\Login::index' , ['filter' => 'noneauth'] );
    $routes->add('products', 'Admin\Product::index' ,['filter' => 'auth']);
    $routes->add('product/item', 'Admin\Product::index' ,['filter' => 'auth']);
    $routes->add('product/item/new', 'Admin\Product::add_product_item' ,['filter' => 'auth']);
	
      $routes->add('profile', 'Admin\Profile::index' ,['filter' => 'auth']);
	  
	  
    $routes->add('product/item/edit/(:num)', 'Admin\Product::edit_product_item/$1' ,['filter' => 'auth']);
	
	
    $routes->add('product/category', 'Admin\Product::product_categories' ,['filter' => 'auth']);
	
	
    $routes->add('product/brand', 'Admin\Product::product_brand' ,['filter' => 'auth']);
	
	
    $routes->add('product/series', 'Admin\Product::product_series' ,['filter' => 'auth']);
	
	
    $routes->add('product/order', 'Admin\Product::order_list' ,['filter' => 'auth']);
	
	
    $routes->add('api', 'Admin\Product::api_airtable' ,['filter' => 'auth']);
	
	
    $routes->add('administrator/list', 'Admin\UserManagement::index' ,['filter' => 'auth']);
    $routes->add('administrator/new', 'Admin\UserManagement::new_admin' ,['filter' => 'auth']);

   $routes->add('client/list', 'Admin\UserManagement::client_list' ,['filter' => 'auth']);
    $routes->add('client/new', 'Admin\UserManagement::new_client' ,['filter' => 'auth']);
    $routes->add('customer/list', 'Admin\UserManagement::customer_list' ,['filter' => 'auth']);
    $routes->add('customer/new', 'Admin\UserManagement::new_customer' ,['filter' => 'auth']);
	


	 $routes->post('create/new-admin', 'Admin\UserManagement::create_new_admin' ,['filter' => 'auth']);
   $routes->post('create/new-client', 'Admin\UserManagement::create_new_client' ,['filter' => 'auth']);
   $routes->post('create/new-customer', 'Admin\UserManagement::create_new_customer' ,['filter' => 'auth']);
	

	 
	 
	 
	 $routes->post('profile/update', 'Admin\Profile::update_profile' ,['filter' => 'auth']);
	 
	 $routes->post('update/password', 'Admin\Profile::update_password');
	 
	 $routes->post('auth/login', 'Auth\AdminAuthentication::authenticate');
	 
	 $routes->get('auth/logout', 'Auth\AdminAuthentication::logout');
	
	
	
	
});




/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php'))
{
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
