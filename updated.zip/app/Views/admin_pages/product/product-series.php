<?= $this->extend($layout) ?>


<?= $this->section('content') ?>
<div class="content-wrapper pb-4 ">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Series</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Series</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	

	 <section class="content">
	 
		
		 <div class="row">
		 	
			<div class="col-md-6">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Details</h3>

             
            </div>
            <div class="card-body">
              <div class="form-group">
                <label for="inputName">Name</label>
                <input type="text" id="inputName" class="form-control">
              </div>
			 
              <div class="form-group">
                <label for="inputDescription">Description</label>
                <textarea id="inputDescription" class="form-control" rows="4"></textarea>
              </div>
			      <div class="form-group">
                <a class="btn btn-block btn-primary" style="width: 20%;" href="<?= base_url('admin/product/item/new') ?>">Add New</a>
              </div>  
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
		  
		  
        </div>
			<div class="col-md-6">
				
			 <table id="category-list" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                  
                        <th>Name <i class="fa fa-sort"></i></th>
                        <th>Description</th>
                        <th>Count <i class="fa fa-sort"></i></th>
                        <th>Action <i class="fa fa-sort"></i></th>
                  </tr>
                  </thead>
                  <tbody>
                  
				  
				  <tr>
                    <td>Android Phone</td>
                    <td>Android Phone
			 
                    </td>
                  
                    <td>3</td>
                  
                    <td >
						<div class="btn-group">
						<button type="button" class="btn btn-success">Action</button>
						<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
						  <span class="sr-only">Toggle Dropdown</span>
						  <div class="dropdown-menu" role="menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-1px, 37px, 0px);">
							<a class="dropdown-item"  href="<?= base_url('admin/product/item/edit/12') ?>">Edit</a>
							<a class="dropdown-item" href="#"  data-toggle="modal" data-target="#modal-danger">Delete</a>
						   
						  </div>
						</button>
					  </div>
				  </td>
                  </tr>
				 
				                   </tfoot>
                </table>
			</div>
		</div >
	 </div>
</div >
  <!-- /.content-wrapper -->
<?= $this->endSection() ?>