<?php 
namespace App\Models\Admin;
use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
	 protected $returnType     = 'array';
    protected $allowedFields = ['user_login', 'created_at', 'user_pass', 'user_nicename', 'user_email', 'user_status', 'display_name', 'country_code'];
	
	
	public function meta_capabilities($pid) {
		
		$db = \Config\Database::connect();
		
		$users_meta = $db->table('users_meta');
		$users_meta->select('meta_key , meta_value');
		$users_meta->where('user_id ', $pid);
		 
		$users_meta->where('meta_key ', "capabilities");
		$users_meta->orWhere('meta_key ', "user_level"); 
		
		$users_meta = $users_meta->get()->getResultArray();
		
		
		$metas = array();
		
		foreach($users_meta as $key => $value){
			//if($value["meta_key"] == "capabilities") $value["meta_value"] = unserialize( $value["meta_value"]);
			
			
			$meta_value = @unserialize( $value["meta_value"]);
			if ( $value["meta_value"]  === 'b:0;' || $meta_value !== false)$value["meta_value"]  = $meta_value ;
			
			$metas[$value["meta_key"]] = $value["meta_value"];
			
		}
		
		// print_r($metas);
		/*if(!empty($meta) ){
			
		} */
		// die();
		return $metas;
	}
	public function get_user_meta( $id = 0, $key = "") {
		
		$db = \Config\Database::connect();
		
		$users_meta = $db->table('users_meta');
		$users_meta->select('meta_key , meta_value');
		$users_meta->where('user_id ', $id);
		$users_meta->where('meta_key ', $key);
		$users_meta->limit(1);
		// 
		$users_meta = $users_meta->get()->getFirstRow('array');
		
		
		$result = "";
			
			
		$meta_value = @unserialize( $value["meta_value"]);
		if ( $users_meta["meta_value"]  === 'b:0;' || $meta_value !== false)$users_meta["meta_value"]  = $meta_value ;
			
		
		if(isset($users_meta['meta_value']))$result = $users_meta['meta_value'];
	
	
		return $result;
	}
	
	public function update_user_meta( $id = 0, $key = "" , $value) {
		
		 $db = \Config\Database::connect();
		
		$users_meta = $db->table('users_meta');
	
		$users_meta->where('user_id ', $id);
		$users_meta->where('meta_key ',$key);
	
		
		
		$isinsert = $users_meta->get()->getFirstRow();
		
		if(empty($isinsert)){
			$data = [
				'user_id ' => $id ,
				'meta_key'       =>  $key,
				'meta_value'       =>  $value,
			];
			return $users_meta->insert($data);
		}
		else{
			
			$users_meta->where('user_id ', $id);
			$users_meta->where('meta_key ',$key);
			$data = [
				'meta_value'       =>  $value,
			];
			
			return $users_meta->update($data);  
		}
		
	
		// return $result;
	}
	public function get_user_inrole($role) {
		
		 $db = \Config\Database::connect();
		$users_meta = $db->table('users_meta');
	
		$users_meta->select('user_id');
		$users_meta->where('meta_key ', "capabilities");
		$users_meta->like('meta_value ', $role);
		
		
		$array_ids = $users_meta->get()->getResult("array");
		
		
		return $array_ids ;
	}
	public function get_all_user($role) {
		 $db = \Config\Database::connect();
		$allusers = array();
		
		
		$users_meta = $db->table('users_meta');
	
		$users_meta->select('user_id');
		$users_meta->where('meta_key ', "capabilities");
		$users_meta->like('meta_value ', $role);
		
		
		$array_ids = $users_meta->get()->getResult("array");
		
		$ids = array();
		
	
		if(empty($array_ids))return$allusers;
		
		 foreach($array_ids as $key => $value){
			 $ids[] = $value['user_id'];
			 
		 }
		 
		 
		  // $users = $db->table('users');
		 $this->whereIn('id', $ids);
		
		
		 $allusers = $this->get()->getResult("array"); 
		
	/* 	
		echo "<pre>";
		print_r($allusers);
		die(); */
		return $allusers;
	}
	
	
	public function create_user($param) {
		
	
		 
		 $userarr = array();
		 $role = array();
		 $userlevel = '';
		 
		 if(isset($param['email']))$userarr['user_email'] = $param['email'];
		 if(isset($param['user_pass']))$userarr['user_pass'] = $param['user_pass'];
		 if(isset($param['user_pass'])){$userarr['user_pass'] = md5($param['user_pass']);unset($param['user_pass']);}
		 if(isset($param['confirmpassword']))unset($param['confirmpassword']);
		 if(isset($param['firstname'])){$userarr['user_login'] = $param['firstname'];$userarr['user_nicename'] = $param['firstname'];$userarr['display_name'] = $param['firstname'];}
		
		
		
		if(isset($userarr['user_pass']) && isset($userarr['user_email']) && isset($userarr['user_login']))$user_id = $this->insert($userarr);
		
		
		 
		 // echo $user_id; 
		 
		//print_r( unserialize('a:1:{s:13:"administrator";b:1;}'));
		 
		 	
		 if(!empty($user_id)){
			 
			 
			
			 
			 if(isset($param['role']) == "administrator"){
				 $role[$param['role']] = true;
				 $userlevel = 'level_10';
				 unset($param['role']);
			 } 
			 if(isset($param['role']) == "customer"){
				 $role[$param['role']] = true;
				 $userlevel = 'level_1';
				 unset($param['role']);
			 } 
			 if(isset($param['role']) == "client"){
				 $role[$param['role']] = true;
				 $userlevel = 'level_5';
				 unset($param['role']);
			 } 
			  if(isset($param['role'])){
				 $role[$param['role']] = true;
				 $userlevel = 'level_5';
				 unset($param['role']);
			 } 
			 
			 
			if(!empty($param)) {
				 foreach($param as $key => $value){
					 
					  if($key != 'capabilities' && $key != 'user_level' && $key != 'redirect' ){
						  $this->update_user_meta( $user_id ,  $key , $value);
					 }
					
					 
					 if(!empty($role)){
						 $this->update_user_meta( $user_id ,  'capabilities', serialize($role));
					 }
					 if(!empty($userlevel)){
						 $this->update_user_meta( $user_id ,  'user_level', $userlevel);
					 } 
				 }
				
			 }
		 
		 }
		 
		
		 
	
		return $user_id;
	}
}