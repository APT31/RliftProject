<?php
	$session = session();
		
	
	
	$getmetacap = "";
	$getcapabilities = "";
	
	if($session->has('user_id')){
		
		if (!function_exists('get_user_capabilities')) {
			
			
			 function get_user_capabilities(  )  {
				 $session = session();
				 $usermodel = new \App\Models\Admin\UserModel();
				 $usercapabiliy = new \App\Models\Admin\UserCapabilityModel();
				 $user_meta = $session->get('user_id');
				
				 
				$getmetacap = $usermodel->meta_capabilities($user_meta);
		
				$getcapabilities = $usercapabiliy->capabilities($getmetacap['capabilities']);

				return $getcapabilities ; 
			}
		
		}
		if (!function_exists('get_user_role')) {
			function get_user_role(  ) {
				$session = session();
				$usermodel = new \App\Models\Admin\UserModel();
				$user_meta = $session->get('user_id');
				$getmetacap = $usermodel->meta_capabilities($user_meta);
				return $getmetacap ;
				
			}
		
		}
		
		if (!function_exists('get_user_meta')) {
			function get_user_meta( $key = "" , $id = null ) {
				$session = session();
				$usermodel = new \App\Models\Admin\UserModel();
				
				$user_meta = $id == null ? $session->get('user_id') : $id;
				
				$metaresult = $usermodel->get_user_meta($user_meta ,  $key);
				
				return $metaresult ;
			}
		
		}
		if (!function_exists('get_user_id')) {
			function get_user_id(  ) {
				$session = session();
				
				$user_id = $session->get('user_id');
				
				return $user_id ;
			}
		
		}
	}
	
	
	
	 
	 

   

