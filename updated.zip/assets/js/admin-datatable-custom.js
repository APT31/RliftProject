/**
* Template Name: Arsha - v3.0.3
* Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/
*/
!(function($) {
  "use strict";

  // Preloader
  $(window).on('load', function() {
		var producttable = jQuery("table#product-list").DataTable();
		var categorytable = jQuery("table#category-list").DataTable();
		var productorderstable = jQuery("table#product-orders").DataTable();
		
		jQuery( producttable.table().container() ).find("#product-list_filter label").addClass("float-right");
		jQuery( producttable.table().container() ).find("ul.pagination").addClass("d-inline-flex float-right");
		
		jQuery( categorytable.table().container() ).find("#category-list_filter label").addClass("float-right");
		jQuery( categorytable.table().container() ).find("ul.pagination").addClass("d-inline-flex float-right");	
		
		jQuery( productorderstable.table().container() ).find("#product-orders_filter label").addClass("float-right");
		jQuery( productorderstable.table().container() ).find("ul.pagination").addClass("d-inline-flex float-right");
		
		
  });


})(jQuery);