<?= $this->extend($layout) ?>


<?= $this->section('content') ?>
<div class="content-wrapper pb-4 ">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Orders</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Orders</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	

	 <section class="content">
	 
		
		 <div class="row">
		 <div class="col-md-12">
		 	 <div class="card">
              <div class="card-header border-0">
                <h3 class="card-title" style="font-weight: 700;">Products</h3>
				<br>
				<span style="    font-size: 12px;    font-weight: 400;">
					23 orders found
				</span>
                <div class="card-tools">
                  <a href="#" class="btn btn-tool btn-sm">
                    <i class="fas fa-download"></i>
                  </a>
                  <a href="#" class="btn btn-tool btn-sm">
                    <i class="fas fa-bars"></i>
                  </a>
                </div>
              </div>
              <div class="card-body table-responsive ">
                <table id="product-orders" class=" table table-striped table-valign-middle p-2">
                  <thead>
                  <tr>
                    <th><input type="checkbox" /></th>
                    <th>Product</th>
                    <th>Service</th>
                    <th>Price</th>
                    <th>Sales</th>
					<th>Category</th>
					<th>Status</th>
					<th>Date</th>
                    <th>More</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td><input type="checkbox" /></td><td><img src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Product 1" class="img-size-64 mr-2 mr-2 mr-2">
                      Some Product
                    </td>
                    <td>Charging Port</td>
                   
                    <td>$13 USD</td>
                    <td>
                      <small class="text-success mr-1">
                        <i class="fas fa-arrow-up"></i>
                        12%
                      </small>
                      12,000 Sold
                    </td>
					 <td>Phone</td>
					 <td>Shipping</td>
					 <td>01/02/2021</td>
                    <td>
                      <a href="#" class="text-muted">
                        <i class="fas fa-search"></i>
                      </a>
                    </td>
                  </tr>
                  
                  <tr>
                    <td><input type="checkbox" /></td><td><img src="<?= base_url('/assets/img/repair-service/smartphone_repair@2x.png') ?>" alt="Product 1" class="img-size-64 mr-2 mr-2 mr-2">
                      Perfect Item
                      <span class="badge bg-danger">NEW</span>
                    </td>
					 <td>Earpiece</td>
                    <td>$199 USD</td>
					
                    <td>
                      <small class="text-success mr-1">
                        <i class="fas fa-arrow-up"></i>
                        63%
                      </small>
                      87 Sold
                    </td>
					<td>Tablet</td>
					<td>Complete</td>
					<td>01/02/2021</td>
                    <td>
                      <a href="#" class="text-muted">
                        <i class="fas fa-search"></i>
                      </a>
                    </td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
            </div>
            <!-- /.card -->
		
		</div >
	 </div>
</div >
  <!-- /.content-wrapper -->
<?= $this->endSection() ?>