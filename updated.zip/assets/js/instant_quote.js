const handleOnLoad = () => {
    $("#quoteSteps").steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slideLeft",
        autoFocus: true
    });

}
window.onload = handleOnLoad;

const handlePageChange = (destination, item_id = 0) => {
    $(`#${destination}Toggle`).tab('show');
}